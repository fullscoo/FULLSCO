// واجهة لاستيراد use-mobile.tsx لضمان التوافق الخلفي
import { useMobile, useIsMobile } from './use-mobile.tsx';
export { useMobile, useIsMobile };
export default useIsMobile;